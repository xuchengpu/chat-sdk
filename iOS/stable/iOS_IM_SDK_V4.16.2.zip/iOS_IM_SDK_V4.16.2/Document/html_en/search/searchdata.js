var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw",
  1: "ein",
  2: "_abcdefgijklmoprstuv",
  3: "abcdefghijlmnoprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Properties"
};

